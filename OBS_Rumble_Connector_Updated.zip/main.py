import tkinter as tk
from tkinter import messagebox
import json
import os
import websocket

SETTINGS_FILE = "settings.json"

def load_settings():
    if os.path.exists(SETTINGS_FILE):
        with open(SETTINGS_FILE, "r") as f:
            return json.load(f)
    return {
        "stream_key": "",
        "rtmp_url": "rtmp://stream.rumble.com/live",
        "obs_password": "",
        "obs_port": "4455"
    }

def save_settings(settings):
    with open(SETTINGS_FILE, "w") as f:
        json.dump(settings, f)

def connect_to_obs(settings):
    try:
        ws = websocket.create_connection(f"ws://localhost:{settings['obs_port']}")
        return ws
    except Exception as e:
        messagebox.showerror("Connection Error", f"Could not connect to OBS WebSocket:
{e}")
        return None

def configure_obs(ws, settings):
    try:
        payload = {
            "op": 6,
            "d": {
                "requestType": "SetStreamServiceSettings",
                "requestId": "1",
                "requestData": {
                    "streamServiceType": "rtmp_custom",
                    "streamServiceSettings": {
                        "server": settings["rtmp_url"],
                        "key": settings["stream_key"],
                        "use_auth": False
                    }
                }
            }
        }
        ws.send(json.dumps(payload))
    except Exception as e:
        messagebox.showerror("OBS Error", f"Failed to configure OBS:
{e}")

def start_stream(ws):
    try:
        ws.send(json.dumps({
            "op": 6,
            "d": {
                "requestType": "StartStream",
                "requestId": "startStream"
            }
        }))
        messagebox.showinfo("Success", "Streaming started successfully!")
    except Exception as e:
        messagebox.showerror("Start Stream Error", f"Could not start stream:
{e}")

def build_gui():
    settings = load_settings()

    root = tk.Tk()
    root.title("OBS ↔ Rumble Connector")
    root.geometry("450x300")
    root.resizable(False, False)

    # Title Label
    tk.Label(root, text="Stream to Rumble from OBS", font=("Helvetica", 14, "bold")).pack(pady=10)

    # RTMP and Stream Key Inputs
    frame = tk.Frame(root)
    frame.pack(pady=5)

    tk.Label(frame, text="Rumble RTMP URL:").grid(row=0, column=0, sticky='e')
    rtmp_url_entry = tk.Entry(frame, width=40)
    rtmp_url_entry.insert(0, settings["rtmp_url"])
    rtmp_url_entry.grid(row=0, column=1, padx=5, pady=2)

    tk.Label(frame, text="Rumble Stream Key:").grid(row=1, column=0, sticky='e')
    stream_key_entry = tk.Entry(frame, width=40, show="*")
    stream_key_entry.insert(0, settings["stream_key"])
    stream_key_entry.grid(row=1, column=1, padx=5, pady=2)

    tk.Label(frame, text="OBS WebSocket Port:").grid(row=2, column=0, sticky='e')
    obs_port_entry = tk.Entry(frame, width=10)
    obs_port_entry.insert(0, settings["obs_port"])
    obs_port_entry.grid(row=2, column=1, sticky='w', pady=2)

    # Status label
    status_label = tk.Label(root, text="", fg="green")
    status_label.pack(pady=5)

    # Button Callback
    def on_start():
        settings["stream_key"] = stream_key_entry.get()
        settings["rtmp_url"] = rtmp_url_entry.get()
        settings["obs_port"] = obs_port_entry.get()
        save_settings(settings)
        ws = connect_to_obs(settings)
        if ws:
            configure_obs(ws, settings)
            start_stream(ws)
            ws.close()
            status_label.config(text="Streaming command sent to OBS.")
        else:
            status_label.config(text="Failed to connect to OBS.", fg="red")

    # Start Button
    tk.Button(root, text="Start Streaming to Rumble", font=("Helvetica", 12), command=on_start).pack(pady=15)

    root.mainloop()

if __name__ == "__main__":
    build_gui()
