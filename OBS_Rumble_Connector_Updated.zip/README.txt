# OBS ↔ Rumble Connector

This is a simple standalone Python GUI tool to help you stream from OBS to Rumble without manually pasting stream keys.

## Features
- Stores your Rumble RTMP settings
- Sends them to OBS via WebSocket
- Starts your stream automatically

## Requirements
- OBS installed
- OBS WebSocket Plugin (v5+)
- Python 3.9+ (or use standalone EXE)

## How to Use
1. Open OBS and make sure WebSocket server is enabled.
2. Run `main.py`.
3. Enter your Rumble stream key and click "Start Stream".
